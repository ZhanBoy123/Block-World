#pragma once

#include "Place.h"
#include "def.h"
#include "Animal.h"
#include "Enum.h"

class GetPlace {
private:
	void getborder() {
		for (int i = 0; i < chang; i++) {
			place[0][i] = things::border;
			place[kuan - 20][i] = things::border;
		}
		for (int i = 0; i < kuan; i++) {
			place[i][0] = things::border;
			place[i][chang - 1] = things::border;
		}
	}

	void Getsum(int high, int fdsa) {// ����������ʯͷ
		int a = getrandom(1, 3);
		if (high + a >= kuan - 1) return;

		for (int i = 1; i <= a; i++) {
			place[++high][fdsa] = things::soil;
		}

		for (int i = high + 1; i < kuan - 1; i++) {
			if (i >= high + 15) {
				int r = getrandom(1, 200);
				if (r >= 199) {
					int sum = getrandom(1, 100);

					if (sum >= 1 && sum <= 65) place[i][fdsa] = things::copper;
					else if (sum >= 66 && sum <= 80) place[i][fdsa] = things::iron;
					else if (sum >= 81 && sum <= 92) place[i][fdsa] = things::gold;
					else place[i][fdsa] = things::diamond;
				}
				else place[i][fdsa] = things::rock;
			}
			else place[i][fdsa] = things::rock;
		}
	}
	void getallthings() {
		int high = kuan / 2;
		int Long = 1;

		while (Long < chang - 1) {
			int Rand = getrandom(1, 3);
			int l = getrandom(10, 17);

			switch (Rand) {
			case 1:
			case 2: {// ����ɽ��
				for (int j = Long; j <= Long + l; j++) {
					if (j >= chang - 1) return;
					else if (high - 1 == 0 || high + 1 == kuan - 1) break;

					int r = getrandom(1, 2);
					switch (r) {
					case 1: high++; break;
					case 2: high--; break;
					}

					place[high][j] = things::grassblock;

					// �����������
					{
						int f = getrandom(1, 2);
						if (f == 1) {
							int getanimal = getrandom(1, 100);
							if (getanimal >= 10 && getanimal <= 20) {
								int g = getrandom(1, 2);

								switch (g) {
								case 1: place[high - 1][j] = things::pig; break;
								case 2: place[high - 1][j] = things::sheep; break;
								}
							}
						}
						else {
							int getanimal = getrandom(1, 100);
							if (getanimal >= 10 && getanimal <= 30) {
								int g = getrandom(1, 1);

								switch (g) {
								case 1: place[high - 1][j] = things::LM; break;
								}
							}
						}
					}

					Getsum(high, j);
				}
			} break;
			case 3: {// ����ƽԭ
				for (int j = Long; j <= Long + l; j++) {
					if (j >= chang - 1) return;
					
					place[high][j] = things::grassblock;
					Getsum(high, j);

					{// ������ �����
						int Tree = getrandom(1, 3);
						int high2 = high;

						if (Tree == 2 && j >= 5 && j <= chang - 6) {// ����
							int tall = getrandom(5, 6);

							for (int g = 0; g < tall; g++) {
								if (high2 - 1 <= 0) break;

								place[--high2][j] = things::wood;

								if (g >= tall / 2) {
									switch (tall) {
									case 5: {
										place[high2][j - 1] = things::leaves;
										place[high2][j - 2] = things::leaves;
										place[high2][j + 1] = things::leaves;
										place[high2][j + 2] = things::leaves;
									} break;
									case 6: {
										place[high2][j - 1] = things::leaves;
										place[high2][j - 2] = things::leaves;
										place[high2][j - 3] = things::leaves;
										place[high2][j + 1] = things::leaves;
										place[high2][j + 2] = things::leaves;
										place[high2][j + 3] = things::leaves;
									} break;
									}
								}
							}

							place[--high2][j] = things::leaves;

							if (tall == 5) {
								place[high2][j + 1] = things::leaves;
								place[high2][j - 1] = things::leaves;
							}
							else {
								place[high2][j + 1] = things::leaves;
								place[high2][j + 2] = things::leaves;
								place[high2][j - 1] = things::leaves;
								place[high2][j - 2] = things::leaves;
							}
						}
					}
				}
			} break;
			}
			Long += l;
		}
	}
public:
	void getall(bool a) {
		if (!a) return;

		getborder();
		getallthings();
		getborder();
	}
};