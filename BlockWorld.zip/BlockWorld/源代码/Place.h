#pragma once

#include <vector>
#include "Enum.h"

const int chang = 940, kuan = 400;
std::vector<std::vector<things>> place(kuan, std::vector<things>(chang, things::air));