#pragma once

#include <vector>
#include <string>
#include <iostream>
#include <windows.h>
#include <climits>
#include <array>
#include "Place.h"
#include "def.h"
#include "colour.h"

#define playerman 24069

std::vector<std::string> bags(45 + 1, "");
std::vector<int> bagcnt(45 + 1, 0);

struct node {
	int x, y;
}pxy;

int k1, k2, c1, c2;
int pointer = 1;
std::string pointerz[10] = {
	" ",// ռλ��
	">",
	" ",
	" ",
	" ",
	" ",
	" ",
	" ",
	" ",
	" ",
};

namespace zl {// ����ָ��
	namespace pzl {// ���ָ��
		const std::string sh = "/switch";
	}

	namespace GZTzl {// ����̨&����ָ��
		const std::string g = "/get";// ����
		const std::string sp = "/swap";// ����
		const std::string tw = "/throw";// ����(�����׳���Ʒ)
	}
}

std::string WorldName = "�µ�����";

bool sc = false;// ��Ϸģʽ
bool rungame = true;// �����Ϸ�Ƿ�����
int foot_and_ps = 1;// �۳�����ֵ����ı���

// ���ڴ浵�ı���
int cdhp, cdps;

class Player {
private:
	int HP;
	int PS;
public:
	Player(int a, int b) : HP(a), PS(b) {}

	void KCPS() {// �۳�����ֵ����
		if (sc == true) return;

		this->PS--;
	}
	void helpcd() {
		cdhp = this->HP;
		cdps = this->PS;
	}

	//==============bag��غ���===============//
	void lookbag() {// �鿴����ʱ
		for (int i = 1; i <= 45; i++) {

			if (i < 10) std::cout << ' ';

			if (!bagcnt[i]) std::cout << "\033[38;5;33m" << i << "):             \033[0m";
			else {
				int Long = bags[i].size();// ��ȡ����
				std::cout << "\033[38;5;33m" << i << "):\033[90m";
				if(
					bags[i] != "ľ��" && bags[i] != "ʯ��" &&
					bags[i] != "ͭ��" && bags[i] != "����" &&
					bags[i] != "��" && bags[i] != "�꽣"
				) std::cout << bags[i] << " * " << bagcnt[i];
				else std::cout << bags[i] << bagcnt[i];
				if      (Long <= 10 && bagcnt[i] < 10)  for (int sum = 1; sum <= (9 - Long); sum++) std::cout << ' ';
				else if (Long <= 10 && bagcnt[i] >= 10) for (int sum = 1; sum <= (8 - Long); sum++) std::cout << ' ';
			}

			if (i % 4 == 0) std::cout << '\n';
			std::cout << "\033[0m";
			
		}
	}
	void set(std::string x) {
		for (int i = 1; i <= 45; i++) {
			if (bags[i] == x && bagcnt[i]) {
				bagcnt[i]--;
				break;
			}
		}
	}
	void get(std::string x) {
		for (int i = 1; i <= 45; i++) {
			if (bags[i] == x && bagcnt[i] < 64) {
				bagcnt[i]++;
				return;
			}
			else if (bags[i] == x && bagcnt[i] >= 64) continue;
		}
		// ����ִ��
		for (int i = 1; i <= 45; i++) {
			if (bags[i] == "") {
				bags[i] = x;
				bagcnt[i]++;
				return;
			}
		}
	}
	//===============Player��غ���===============//
	void getplayer(bool a) {
		if (!a) return;

		pxy.x = getrandom(25, chang - 26);
		pxy.y = 0;

		while (place[pxy.y + 1][pxy.x] == things::air) pxy.y++;

		place[pxy.y][pxy.x] = things(playerman);

		k1 = pxy.y - 7;
		k2 = pxy.y + 7;

		c1 = pxy.x - 8;
		c2 = pxy.x + 8;
	}
	int look(std::string n) {
		if (n == "HP")       return this->HP;
		else if (n == "PS")  return this->PS;
	}
	void down(bool sc) {
		auto print = [](int a, int b, int c, int d) -> void {
			int cnt = 1;

			std::cout << " \033[95m________________________________\n";
			for (int k1 = a; k1 <= b; k1++) {

				std::cout << "\033[95m|";
				for (int c1 = c; c1 < d; c1++) {
					switch (place[k1][c1]) {
					case things::air:           std::cout << SC; break;
					case things::border:        std::cout << colour::border; break;
					case things::grassblock:    std::cout << colour::grassblock; break;
					case things::rock:          std::cout << colour::rock; break;
					case things::soil:          std::cout << colour::soil; break;
					case things::wood:          std::cout << colour::wood; break;
					case things::leaves:        std::cout << colour::leaves; break;
					case things(playerman):     std::cout << "\033[47m\033[34m��"; break;
					case things::copper:        std::cout << colour::copper; break;
					case things::iron:          std::cout << colour::iron; break;
					case things::gold:          std::cout << colour::gold; break;
					case things::diamond:       std::cout << colour::diamond; break;
					case things::pig:           std::cout << colour::canimal::cpig; break;
					case things::sheep:         std::cout << colour::canimal::csheep; break;
					case things::RLQ:           std::cout << colour::cpr::cRLQ; break;
					case things::LM:            std::cout << SC << "\b\b" << colour::cplant::cLM; break;
					}
					if (k1 == b) std::cout << "\b\b\033[95m__";
				}

				std::cout << "\033[0m\033[95m|\033[0m                    \b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b";

				if (cnt <= 9) std::cout << " " << pointerz[cnt] << ' ';
				if (cnt <= 9 && bagcnt[cnt] != 0) {
					if (
						bags[cnt] != "ľ��" && bags[cnt] != "ʯ��" &&
						bags[cnt] != "ͭ��" && bags[cnt] != "����" &&
						bags[cnt] != "��" && bags[cnt] != "�꽣"

						) std::cout << " " << bags[cnt] << " * " << bagcnt[cnt];
				}
				if (cnt <= 9 && bagcnt[cnt] <= 0) {
					bagcnt[cnt] = 0;
					bags[cnt] = "";
				}
				std::cout << "\n";
				cnt++;
			}

			std::cout << "\033[Jx:" << pxy.x << " y:" << pxy.y << "\n";
		};

		if (sc == true) return;
		int high = 0, time = 60;

		while (place[pxy.y + 1][pxy.x] == things::air) {
			std::cout << "\033[H";
			print(k1, k2, c1, c2);
			{
				std::cout << "Ѫ����";
				if (this->HP >= 7)      std::cout << "\033[92m" << this->HP << "\033[0m ";
				else if (this->HP >= 4) std::cout << "\033[33m" << this->HP << "\033[0m ";
				else                    std::cout << "\033[91m" << this->HP << "\033[0m ";

				std::cout << "����ֵ��";
				if (this->PS >= 7)      std::cout << "\033[92m" << this->PS << "\033[0m";
				else if (this->PS >= 4) std::cout << "\033[33m" << this->PS << "\033[0m";
				else                    std::cout << "\033[91m" << this->PS << "\033[0m";
			}

			Sleep(time);
			if (time > 10) time -= 10;

			place[++pxy.y][pxy.x] = things(playerman);
			place[pxy.y - 1][pxy.x] = things::air;
			k1++;
			k2++;
			high++;
		}

		// ˤ���˺�
		if (high >= 4) {
			this->HP -= high / 2;
			Beep(5000, 10);
		}
	}
	void move(char c, bool sc) {
		switch (c) {
		case 'W': case 'w': {
			if (!sc) return;
			if (place[pxy.y - 1][pxy.x] == things::air && pxy.y - 1 >= 10) {
				place[--pxy.y][pxy.x] = things(playerman);
				place[pxy.y + 1][pxy.x] = things::air;
				k1--;
				k2--;
			}
		} break;
		case 'S': case 's': {
			if (!sc) return;
			if (place[pxy.y + 1][pxy.x] == things::air && pxy.y + 1 <= kuan - 10) {
				place[++pxy.y][pxy.x] = things(playerman);
				place[pxy.y - 1][pxy.x] = things::air;
				k1++;
				k2++;
			}
		} break;
		case 'A': case 'a': {
			if (pxy.x - 1 >= 10) {
				if (place[pxy.y][pxy.x - 1] != things::air && place[pxy.y - 1][pxy.x - 1] == things::air) {
					place[--pxy.y][--pxy.x] = things(playerman);
					place[pxy.y + 1][pxy.x + 1] = things::air;
					c1--; k1--;
					c2--; k2--;
				}
				else if (place[pxy.y][pxy.x - 1] == things::air) {
					place[pxy.y][--pxy.x] = things(playerman);
					place[pxy.y][pxy.x + 1] = things::air;
					c1--;
					c2--;
				}
			}
		} break;
		case 'D': case 'd': {
			if (pxy.x + 1 <= chang - 10) {
				if (place[pxy.y][pxy.x + 1] != things::air && place[pxy.y - 1][pxy.x + 1] == things::air) {
					place[--pxy.y][++pxy.x] = things(playerman);
					place[pxy.y + 1][pxy.x - 1] = things::air;
					c1++; k1--;
					c2++; k2--;
				}
				else if (place[pxy.y][pxy.x + 1] == things::air) {
					place[pxy.y][++pxy.x] = things(playerman);
					place[pxy.y][pxy.x - 1] = things::air;
					c1++;
					c2++;
				}
			}
		} break;
		}
	}

	std::string pd_get_str(things f) {// �����ھ�
		switch (f) {
		case things::grassblock:         return "�ݷ���"; break;
		case things::rock:               return "ʯͷ"; break;
		case things::soil:               return "����"; break;
		case things::leaves:             return "��Ҷ"; break;
		case things::wood:               return "ľ��"; break;
		case things::copper:             return "ԭͭ��"; break;
		case things::iron:               return "ԭ����"; break;
		case things::gold:               return "ԭ���"; break;
		case things::diamond:            return "ԭ���"; break;
		case things::LM:                 return "����"; break;
		case things::RLQ:                return "������"; break;
		default:                         return "??"; break;
		}
	}
	things pd_get_int(std::string f) {// ���ڷ���
		if (f == "�ݷ���")         return things::grassblock;
		else if (f == "ʯͷ")      return things::rock;
		else if (f == "����")      return things::soil;
		else if (f == "��Ҷ")      return things::leaves;
		else if (f == "ľ��")      return things::wood;
		else if (f == "ԭͭ��")    return things::copper;
		else if (f == "ԭ����")    return things::iron;
		else if (f == "ԭ���")    return things::gold;
		else if (f == "ԭ���")    return things::diamond;
		else if (f == "������")    return things::RLQ;
		else return things::air;
	}
	void __RLQ__() {// ������

		auto find = []() -> bool {
			for (int i = 1; i <= 45; i++) {
				if (bags[i] == "ľ��") return true;
			}
		};

		while (true) {
			clear();
			std::cout << "\033[92m������\033[0m\n\n\033[?25h";
			lookbag();
			std::cout << "\nָ��->";

			std::string s = "";
			std::cin >> s;

			if (s == "e" || s == "E") {// �˳�
				clear();
				return;
			}

			if (s == "/r") {
				int a;

				try {
					std::cin.exceptions(std::ios::failbit | std::ios::badbit);// ���д�����Դ��AI��������
					std::cin >> a;
				}
				catch (const std::ios_base::failure& e) {
					std::cerr << "�������Ͳ���ȷ��";
					Sleep(1000);
					std::cin.clear();
					continue;
					//std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
				}
				if (bags[a] != "" && find()) {
					for (int i = 1; i <= 45; i++) {
						if (bags[i] == "ľ��") { 
							bagcnt[i]--;
							break;
						}
					}

					{// �ϳ��䷽
						if (bags[a] == "ԭͭ��")        get("ͭ��");
						else if (bags[a] == "ԭ����")   get("����");
						else if (bags[a] == "ԭ���")   get("��");
						else if (bags[a] == "ԭ���")   get("��ʯ");
						else if (bags[a] == "������")   get("������");
						else continue;
						bagcnt[a]--;
						for (int i = 1; i <= 45; i++) {
							if (bags[i] == "ľ��") {
								bagcnt[i]--;
								break;
							}
						}
					}
				}
		}
		
		}
	}
	void woc(char c) {// �ھ�&����&����
		int Long;
		bool use = false;
		if (
			bags[pointer] == "ľ��->" ||
			bags[pointer] == "ʯ��->" ||
			bags[pointer] == "ͭ��->" ||
			bags[pointer] == "����->" ||
			bags[pointer] == "��->" ||
			bags[pointer] == "��ʯ��->"
			) {
			use = true;
			Long = 6;
		}
		else Long = 4;

		switch (c) {
		// �ھ��빥��
		case 'i': {
			for (int i = 1; i <= Long; i++) {

				if (place[pxy.y - i][pxy.x] == things::pig || place[pxy.y - i][pxy.x] == things::sheep) {
					if (use) bagcnt[pointer]--;

					place[pxy.y - i][pxy.x] = things::air;
					get("������");
					break;
				}
				else if (place[pxy.y - i][pxy.x] != things::air) {
					get(pd_get_str(place[pxy.y - i][pxy.x]));
					place[pxy.y - i][pxy.x] = things::air;
					Beep(1000, 10);
					break;
				}
			}
		} break;
		case 'k': {
			for (int i = 1; i <= Long; i++) {
				if (place[pxy.y + i][pxy.x] == things::border) break;

				if (place[pxy.y + i][pxy.x] == things::pig || place[pxy.y + i][pxy.x] == things::sheep) {
					if (use) bagcnt[pointer]--;

					place[pxy.y + i][pxy.x] = things::air;
					get("������");
					break;
				}
				else if (place[pxy.y + i][pxy.x] != things::air) {
					get(pd_get_str(place[pxy.y + i][pxy.x]));
					place[pxy.y + i][pxy.x] = things::air;
					Beep(1000, 10);
					break;
				}
			}
		} break;
		case 'j': {
			for (int i = 1; i <= Long; i++) {
				if (place[pxy.y][pxy.x - i] == things::pig || place[pxy.y][pxy.x - i] == things::sheep) {
					if (use) bagcnt[pointer]--;

					place[pxy.y][pxy.x - i] = things::air;
					get("������");
					break;
				}
				else if (place[pxy.y][pxy.x - i] != things::air) {
					get(pd_get_str(place[pxy.y][pxy.x - i]));
					place[pxy.y][pxy.x - i] = things::air;
					Beep(1000, 10);
					break;
				}
			}
		} break;
		case 'l': {
			for (int i = 1; i <= Long; i++) {
				if (place[pxy.y][pxy.x + i] == things::pig || place[pxy.y][pxy.x + i] == things::sheep) {
					if (use) bagcnt[pointer]--;

					place[pxy.y][pxy.x + i] = things::air;
					get("������");
					break;
				}
				else if (place[pxy.y][pxy.x + i] != things::air) {
					get(pd_get_str(place[pxy.y][pxy.x + i]));
					place[pxy.y][pxy.x + i] = things::air;
					Beep(1000, 10);
					break;
				}
			}
		} break;
		
		// ����
		case 'I': {
			if (bagcnt[pointer] <= 0) return;
			for (int i = 1; i <= 4; i++) {
				if (place[pxy.y - i][pxy.x] == things::air && place[pxy.y - i - 1][pxy.x] != things::air) {
					if (pd_get_int(bags[pointer]) == things::air) return;
					place[pxy.y - i][pxy.x] = pd_get_int(bags[pointer]);
					bagcnt[pointer]--;
					Beep(900, 10);
					break;
				}
			}
		} break;
		case 'K': {
			if (bagcnt[pointer] <= 0) return;

			if (place[pxy.y + 1][pxy.x] != things::air && place[pxy.y - 1][pxy.x] == things::air && k1 >= 10) {
				if (pd_get_int(bags[pointer]) == things::air) return;
				place[pxy.y][pxy.x] = pd_get_int(bags[pointer]);
				place[--pxy.y][pxy.x] = things(playerman);
				bagcnt[pointer]--;
				k1--;
				k2--;
				Beep(900, 10);
				return;// ֱ���˳�����
			}

			for (int i = 1; i <= 4; i++) {
				if (place[pxy.y + i][pxy.x] == things::air && place[pxy.y + i + 1][pxy.x] != things::air) {
					if (pd_get_int(bags[pointer]) == things::air) return;
					place[pxy.y + i][pxy.x] = pd_get_int(bags[pointer]);
					bagcnt[pointer]--;
					Beep(900, 10);
					break;
				}
			}
		} break;
		case 'J': {
			if (bagcnt[pointer] <= 0) return;
			for (int i = 1; i <= 4; i++) {
				if (place[pxy.y][pxy.x - i] == things::air && place[pxy.y][pxy.x - i - 1] != things::air) {
					if (pd_get_int(bags[pointer]) == things::air) return;
					place[pxy.y][pxy.x - i] = pd_get_int(bags[pointer]);
					bagcnt[pointer]--;
					Beep(900, 10);
					break;
				}
			}
		} break;
		case 'L': {
			if (bagcnt[pointer] <= 0) return;
			for (int i = 1; i <= 4; i++) {
				if (place[pxy.y][pxy.x + i] == things::air && place[pxy.y][pxy.x + i + 1] != things::air) {
					if (pd_get_int(bags[pointer]) == things::air) return;
					place[pxy.y][pxy.x + i] = pd_get_int(bags[pointer]);
					bagcnt[pointer]--;
					Beep(900, 10);
					break;
				}
			}
		} break;
		// ���ָ��
		case 't': {
			std::cout << "\n\033[?25hָ���->\033[4m                                  \033[0m\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b";

			std::string ZL = "";
			std::cin >> ZL;

			if (ZL == zl::pzl::sh) sc = !sc;
			else if (ZL == "/open") {
				char n = 'f';
				std::cin >> n;

				switch (n) {
				case 'a': {
					for (int i = 1; i <= 4; i++) {
						if (place[pxy.y][pxy.x - i] == things::RLQ) {
							__RLQ__();
							break;
						}
					}
				} break;
				case 's': {
					for (int i = 1; i <= 4; i++) {
						if (place[pxy.y + i][pxy.x] == things::RLQ) {
							__RLQ__();
							break;
						}
					}
				} break;
				case 'w': {
					for (int i = 1; i <= 4; i++) {
						if (place[pxy.y - i][pxy.x] == things::RLQ) {
							__RLQ__();
							break;
						}
					}
				} break;
				case 'd': {
					for (int i = 1; i <= 4; i++) {
						if (place[pxy.y][pxy.x + i] == things::RLQ) {
							__RLQ__();
							break;
						}
					}
				} break;
				}
			}
			std::cout << "\033[?25l";
		} break;
		case 'p': {// ��
			if (bags[pointer] == "������") {
				// �Զ���
				if (this->PS <= 8) {
					this->PS += 2;
					foot_and_ps = 0;
				}
				else {
					PS = 10;
					foot_and_ps = 0;
				}
				bagcnt[pointer]--;
			}
			else if (bags[pointer] == "������") {
				// �Զ���
				if (this->PS <= 9) this->PS++;
				else PS = 10;
				bagcnt[pointer]--;
			}
			else if (bags[pointer] == "����") {
				// �Զ���
				if (this->PS <= 9 && this->HP <= 9) {
					this->PS++;
					this->HP++;
				}
				else if (this->PS <= 9) {
					this->PS++;
				}
				else {
					this->PS = 10;
					this->HP = 10;
				}
				bagcnt[pointer]--;
			}
		} break;
		}
	}
	void switch_pointer(char n) {// �л���Ʒ��ָ�뺯��
		if (n >= '1' && n <= '9') {
			pointerz[pointer] = " ";
			pointer = int(n) - 48;
			pointerz[pointer] = ">";
		}
	}

	void things_get(std::string name, int sum) {// �ϳ� �ؼ�����
		auto see = [sum](std::string n, int othersum) -> bool {
			for (int i = 1; i <= 45; i++) {
				if (bags[i] == n) {
					if (bagcnt[i] > sum * othersum) {
						bagcnt[i] -= sum * othersum;
						return true;
					}
					else if (bagcnt[i] == sum * othersum) {
						bags[i] = "";
						bagcnt[i] = 0;
						return true;
					}
					else continue;
				}
			}
			return false;
		};

		if (name == "ľ��" && (see("ľ��", 2) && see("ľ��", 1)))       for (int i = 1; i <= 30; i++) get(name + "->");
		else if (name == "ʯ��" && (see("ʯͷ", 2) && see("ľ��", 1)))  for (int i = 1; i <= 40; i++) get(name + "->");
		else if (name == "ͭ��" && (see("ͭ��", 2) && see("ľ��", 1)))  for (int i = 1; i <= 40; i++) get(name + "->");
		else if (name == "����" && (see("����", 2) && see("ľ��", 1)))  for (int i = 1; i <= 45; i++) get(name + "->");
		else if (name == "��" && (see("��", 2) && see("ľ��", 1)))  for (int i = 1; i <= 32; i++) get(name + "->");
		else if (name == "�꽣" && (see("��ʯ", 2) && see("ľ��", 1)))  for (int i = 1; i <= 60; i++) get(name + "->");

		else if (name == "ľ��" && see("ľ��", 1))                      while (sum--) get(name);
		else if (name == "������" && see("ʯͷ", 10))                   while (sum--) get(name);
		else {
			std::cout << "�ϳ�ʧ�ܣ�\n";
			Sleep(1000);
		}
			
	}
	void other(char n) {

		switch (n) {
		case 'e': case 'E': {

			std::string gztstr[3][3] = {
				{"_", "_", "_"},
				{"_", "_", "_"},
				{"_", "_", "_"}
			};
			things gztint[3][3] = {};
			std::cout << "\033[?25h";

			while (true) {
				clear();
				for (int i = 0; i < 3; i++) {
					for (int j = 0; j < 3; j++) {
						std::cout << gztstr[i][j] << ' ';
					}
					std::cout << "\n";
				}
				lookbag();

				std::cout << "\nָ��->";

				std::string sum = "";
				std::cin >> sum;

				// ָ���жϡ�
				// ����ָ��
				if (sum == "E" || sum == "e") {// �˳�����
					clear();
					return;
				}
				else if (sum == zl::GZTzl::g) {// �ϳ�ָ��
					std::string a;
					int b;

					try {
						std::cin.exceptions(std::ios::failbit | std::ios::badbit);// ���д�����Դ��AI��������
						std::cin >> a >> b;
					}
					catch (const std::ios_base::failure& e) {
						std::cerr << "�������Ͳ���ȷ��";
						Sleep(1000);
						std::cin.clear();
						continue;
						//std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
					}

					things_get(a, b);
				}
				else if (sum == zl::GZTzl::sp) {// ����ָ��
					int a, b;

					try {
						std::cin.exceptions(std::ios::failbit | std::ios::badbit);// ���д�����Դ��AI��������
						std::cin >> a >> b;
					}
					catch (const std::ios_base::failure& e) {
						std::cerr << "�������Ͳ���ȷ��";
						Sleep(1000);
						std::cin.clear();
						continue;
						//std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
					}

					std::swap(bagcnt[a], bagcnt[b]);
					std::swap(bags[a], bags[b]);
				}
				else if (sum == zl::GZTzl::tw) {// �ӳ���Ʒָ��
					int a;
					try {
						std::cin.exceptions(std::ios::failbit | std::ios::badbit);// ���д�����Դ��AI��������
						std::cin >> a;
					}
					catch (const std::ios_base::failure& e) {
						std::cerr << "�������Ͳ���ȷ��";
						Sleep(1000);
						std::cin.clear();
						continue;
						//std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
					}
					bags[a] = "";
					bagcnt[a] = 0;
				}
			}
		} break;
		}
	}
	void DIE_OR_WIN() {
		if (this->HP <= 0 || this->PS <= 0) rungame = false;
	}
};