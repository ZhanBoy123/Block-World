#pragma once

#include "def.h"
#include "GetPlace.h"
#include "Player.h"
#include "Place.h"

class Animal {
public:
	void down() {
		for (int i = k1; i <= k2; i++) {
			for (int j = c1; j <= c2; j++) {
				if ((place[i][j] == things::pig || place[i][j] == things::sheep) && place[i + 1][j] == things::air) {
					place[i + 1][j] = place[i][j];
					place[i][j] = things::air;
				}
			}
		}
	}
	void move() {
		int Run_yn = getrandom(1, 2);

		if (Run_yn) {
			for (int i = k1; i <= k2; i++) {
				for (int j = c1; j <= c2; j++) {
					if (place[i][j] == things::pig || place[i][j] == things::sheep) {
						int yn2 = getrandom(1, 2);
						if (yn2 == 1 && place[i][j - 1] == things::air) place[i][j - 1] = place[i][j];
						else if (yn2 == 2 && place[i][j + 1] == things::air) place[i][j + 1] = place[i][j];
						// 特殊情况
						else if (yn2 == 1 && (place[i][j - 1] != things::air && place[i - 1][j - 1] == things::air)) place[i - 1][j - 1] = place[i][j];
						else if (yn2 == 2 && (place[i][j + 1] != things::air && place[i - 1][j + 1] == things::air)) place[i - 1][j + 1] = place[i][j];

						place[i][j] = things::air;
					}
				}
			}
		}
	}
};