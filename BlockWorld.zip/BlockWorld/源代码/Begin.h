#pragma once

#include <iostream>
#include <windows.h>
#include <conio.h>
#include "def.h"
#include "cd.h"

bool opencd = true;

int fm[20][20] = {
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
	{0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0},
	{0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0},
	{0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0},
	{0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0},
	{0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0},
	{0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0},
	{0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0},
	{0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0},
	{0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0},
	{0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0},
	{0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0},
	{0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0},
	{0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0},
	{0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0},
	{0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0},
	{0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0},
	{0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
};

void begin() {
	for (int i = 0; i < 20; i++) {
		for (int j = 0; j < 20; j++) {
			switch (fm[i][j]) {
			case 0: std::cout << "\033[41m  "; break;
			case 1: std::cout << "\033[103m  "; break;
			case 2: std::cout << "\033[43m  "; break;
			}
		}
		std::cout << "\033[0m\n";
	}

	Sleep(2000);
	clear();

	std::cout << "��ӭ������ʽ��BlockWorld��\n�����������>>";
	char fdsa = _getch();
	clear();

	// ��Ϸ����
	std::string point[4] = {
		">",
		" ",
		" ",
		" "
	};
	int pointer = 0;

	while (true) {
		clear();
		std::cout << "\033[96m"
			<< point[0] << " ���ش浵\n"
			<< point[1] << " ��������\n"
			<< point[2] << " ��Ϸģʽ\n"
			<< point[3] << " ȷ������\n\033[0m";
		char n = _getch();

		switch (n) {
		case 'w': {
			if (pointer <= 0) continue;

			pointer--;
			point[pointer] = ">";
			point[pointer + 1] = " ";
		} break;
		case 's': {
			if (pointer >= 3) continue;

			pointer++;
			point[pointer] = ">";
			point[pointer - 1] = " ";
		} break;
		case 'o': {
			switch (pointer) {
			case 0: {
				std::cout << "������浵��->";
				std::string s;
				std::cin >> s;
				cd::getcd(s);
				opencd = false;
				clear();
				return;
			} break;
			case 1: {
				std::cout << "��������������->";
				std::cin >> WorldName;
			} break;
			case 2: {
				std::cout << "1������\n2������\n������>>";
				int n;
				std::cin >> n;
				if (n == 1)      sc = false;
				else if (n == 2) sc = true;
			} break;
			case 3: {
				std::cout << "���ã�\n";
				std::cout
					<< "�������ƣ�" << WorldName << "\n"
					<< "��Ϸģʽ��" << ((sc) ? "����" : "����");
				std::cout << "\n�Ƿ��������(y/n)>>";

				char sum = _getch();
				if (sum == 'n') continue;
				else {
					std::cout << "\n��������...\n";
					Sleep(2000);
					clear();
					return;
				}
			} break;
			}
		} break;
		}
	}
}