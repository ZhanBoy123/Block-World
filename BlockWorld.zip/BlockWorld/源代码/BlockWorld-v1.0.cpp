﻿#include <iostream>
#include <windows.h>
#include <conio.h>
#include <string>
#include "GetPlace.h"
#include "Player.h"
#include "Animal.h"
#include "colour.h"
#include "cd.h"
#include "Begin.h"

void print(int a, int b, int c, int d) {
    int cnt = 1;

    std::cout << " \033[95m________________________________\n";
    for (int k1 = a; k1 <= b; k1++) {

        std::cout << "\033[95m|";
        for (int c1 = c; c1 < d; c1++) {
            switch (place[k1][c1]) {
            case things::air:           std::cout << SC; break;
            case things::border:        std::cout << colour::border; break;
            case things::grassblock:    std::cout << colour::grassblock; break;
            case things::rock:          std::cout << colour::rock; break;
            case things::soil:          std::cout << colour::soil; break;
            case things::wood:          std::cout << colour::wood; break;
            case things::leaves:        std::cout << colour::leaves; break;
            case things(playerman):     std::cout << "\033[47m\033[34m你"; break;
            case things::copper:        std::cout << colour::copper; break;
            case things::iron:          std::cout << colour::iron; break;
            case things::gold:          std::cout << colour::gold; break;
            case things::diamond:       std::cout << colour::diamond; break;
            case things::pig:           std::cout << colour::canimal::cpig; break;
            case things::sheep:         std::cout << colour::canimal::csheep; break;
            case things::RLQ:           std::cout << colour::cpr::cRLQ; break;
            case things::LM:            std::cout << SC << "\b\b" << colour::cplant::cLM; break;
            }
            if (k1 == b) std::cout << "\b\b\033[95m__";
        }

        std::cout << "\033[0m\033[95m|\033[0m                    \b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b";

        if(cnt <= 9) std::cout << " " << pointerz[cnt] << ' ';
        if (cnt <= 9 && bagcnt[cnt] != 0) {
            if(
                bags[cnt] != "木剑" && bags[cnt] != "石剑" && 
                bags[cnt] != "铜剑" && bags[cnt] != "铁剑" &&
                bags[cnt] != "金剑" && bags[cnt] != "钻剑"

            ) std::cout << " " << bags[cnt] << " * " << bagcnt[cnt];
        }
        if (cnt <= 9 && bagcnt[cnt] <= 0) {
            bagcnt[cnt] = 0;
            bags[cnt] = "";
        }
        std::cout << "\n";
        cnt++;
    }

    std::cout << "\033[Jx:" << pxy.x << " y:" << pxy.y << "\n";
}

namespace BlockWorld {
    std::string back = "";

    void game(bool a) {
        // 启用 Windows 虚拟终端支持
        HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
        DWORD dwMode = 0;
        GetConsoleMode(hOut, &dwMode);
        dwMode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
        SetConsoleMode(hOut, dwMode);

        srand(time(0));

        int fdsa, fdsa2;

        if (!a) {
            fdsa = cdhp;
            fdsa2 = cdps;
        }
        else {
            fdsa = 10;
            fdsa2 = 10;
        }
        
        GetPlace* p = new GetPlace;
        p->getall(a);
        delete p;
        Player* player = new Player(fdsa, fdsa2);
        Animal* animal = new Animal;

        player->getplayer(a);

       
        char n = ' ';
        std::cout << "\033[?25l";

        while (n != 27 && rungame) {
            player->DIE_OR_WIN();// 判断游戏是否继续

            print(k1, k2, c1, c2);

            {
                std::cout << "血量：";
                if (player->look("HP") >= 7)      std::cout << "\033[92m" << player->look("HP") << "\033[0m ";
                else if (player->look("HP") >= 4) std::cout << "\033[33m" << player->look("HP") << "\033[0m ";
                else                              std::cout << "\033[91m" << player->look("HP") << "\033[0m ";

                std::cout << "饥饿值：";
                if (player->look("PS") >= 7)      std::cout << "\033[92m" << player->look("PS") << "\033[0m";
                else if (player->look("PS") >= 4) std::cout << "\033[33m" << player->look("PS") << "\033[0m";
                else                              std::cout << "\033[91m" << player->look("PS") << "\033[0m";
            }

            animal->move();
            animal->down();

            n = _getch();

            player->woc(n);
            player->switch_pointer(n);
            player->move(n, sc);
            player->other(n);
            player->down(sc);
            player->helpcd();

            std::cout << "\033[H";
            std::cout << "\033[?25l";

            player->DIE_OR_WIN();// 判断游戏是否继续

            skycolourbh();
            ss++;
            foot_and_ps++;

            if (foot_and_ps == 80) {// 扣除饥饿值
                foot_and_ps = 0;
                player->KCPS();
            }
        }

        delete player;
        delete animal;
        clear();
        
        if (!rungame)  back = "careless";
        else           back = "put esc";

        std::cout << "\033[92m退出原因：\033[95m" << back << "\033[0m";

        if (back == "put esc") {// 只有正常退出才有存档
            std::cout << "\n已自动保留存档！";
            cd::putcd(WorldName);
        }

        std::cout << "\n按任意键退出>>";
        char tc = _getch();
    }
}

int main() {
    begin();
    BlockWorld::game(opencd);
}