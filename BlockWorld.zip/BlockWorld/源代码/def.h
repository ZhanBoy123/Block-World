#pragma once

#include <ctime>
#include <cstdlib>
#include <iostream>
#include <windows.h>
#include "colour.h"

int getrandom(int min, int max) {
    return (rand() % (max - min + 1)) + min;
}

void clear() {
    std::cout << "\033[H\033[J";
}

// sky def
std::string SC = colour::sky::a;
int ss = 1;

void skycolourbh() {
    std::string sc2 = "";

    if (ss > 200) {
        ss = 1;
        sc2 = colour::sky::g;
        return;
    }

    if (ss <= 20) sc2 = colour::sky::a;
    else if (ss <= 30) sc2 = colour::sky::b;
    else if (ss <= 50) sc2 = colour::sky::c;
    else if (ss <= 80) sc2 = colour::sky::d;
    else if (ss <= 140) sc2 = colour::sky::e;
    else if (ss <= 180) sc2 = colour::sky::f;
    else if (ss <= 200) sc2 = colour::sky::g;

    SC = sc2;
}
