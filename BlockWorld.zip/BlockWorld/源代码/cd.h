#pragma once

#include <fstream>
#include "def.h"
#include "Player.h"

namespace cd {
	int helpdef(things sum) {
		switch (sum) {
		case things::air:         return 0; break;
		case things::border:      return 1; break;
		case things::grassblock:  return 2; break;
		case things::soil:        return 3; break;
		case things::rock:        return 4; break;
		case things::leaves:      return 5; break;
		case things::wood:        return 6; break;
		case things::copper:      return 7; break;
		case things::iron:        return 8; break;
		case things::gold:        return 9; break;
		case things::diamond:     return 10; break;
		case things::pig:         return 11; break;
		case things::sheep:       return 12; break;
		case things::LM:          return 13; break;
		case things::RLQ:         return 14; break;
		case things(24069):   return 24069; break;
		}
	}
	things helpdef2(int sum) {
		switch (sum) {
		case 0:         return things::air; break;
		case 1:      return things::border; break;
		case 2:  return things::grassblock; break;
		case 3:        return things::soil; break;
		case 4:        return things::rock; break;
		case 5:      return things::leaves; break;
		case 6:        return things::wood; break;
		case 7:      return things::copper; break;
		case 8:        return things::iron; break;
		case 9:        return things::gold; break;
		case 10:     return things::diamond; break;
		case 11:         return things::pig; break;
		case 12:       return things::sheep; break;
		case 13:          return things::LM; break;
		case 14:   return things::RLQ; break;
		case 24069:   return things(24069); break;
		}
	}

	int sum = 0;

	void putcd(std::string name) {
		std::ofstream file;
		file.open(name + ".txt");

		for (int i = 0; i < kuan; i++) {
			for (int j = 0; j < chang; j++) {
				file << helpdef(place[i][j]) << ' ';// 储存地图
			}
		}

		// 储存玩家基本情况

		file << cdhp << ' ' << cdps << ' ';
		file << k1 << ' ' << k2 << ' ' << c1 << ' ' << c2 << ' ';// 界面
		file << rungame << ' ' << foot_and_ps << ' ';
		file << pxy.y << ' ' << pxy.x << ' ';

		// 其他
		file << ss << ' ' << sc;

		file.close();

		// 储存背包
		std::ofstream file2;
		file2.open(name + "_allbag" + ".txt");

		for (int i = 1; i <= 45; i++) {
			if (bags[i] == "" || bagcnt[i] == 0) continue;
			sum++;
		}

		file2 << sum << ' ';

		for (int i = 1; i <= 45; i++) {
			if (bags[i] == "" || bagcnt[i] == 0) continue;
			file2 << bags[i] << ' ' << bagcnt[i] << ' ';
		}

		file2.close();
	}
	void getcd(std::string name) {
		std::ifstream file;
		file.open(name + ".txt");

		for (int i = 0; i < kuan; i++) {
			for (int j = 0; j < chang; j++) {
				int sum;
				file >> sum;
				place[i][j] = helpdef2(sum);
			}
		}

		// 储存玩家基本情况

		file >> cdhp >> cdps;
		file >> k1 >> k2 >> c1 >> c2;// 界面
		file >> rungame >> foot_and_ps;
		file >> pxy.y >> pxy.x;
		
		// 其他
		file >> ss >> sc;

		file.close();

		// 读取背包
		std::ifstream file2;
		file2.open(name + "_allbag" + ".txt");

		file2 >> sum;
		for (int i = 1; i <= sum; i++) {
			file2 >> bags[i] >> bagcnt[i];
		}

		file2.close();
	}
}