#pragma once

#include <string>

namespace colour {

    namespace sky {// 天空颜色
        std::string a = "\033[48;5;20m  ";
        std::string b = "\033[48;5;26m  ";
        std::string c = "\033[48;5;33m  ";
        std::string d = "\033[48;5;39m  ";
        std::string e = "\033[48;5;45m  ";
        std::string f = "\033[48;5;11m  ";
        std::string g = "\033[48;5;16m  ";
    }

    namespace canimal {// 动物颜色
        std::string cpig = "\033[48;5;198m\033[38;5;0m,,";
        std::string csheep = "\033[48;5;255m\033[38;5;0m,,";
    }
    namespace cplant {// 植物颜色
        std::string cLM = "\033[38;5;118m||";
    }
    namespace cpr {
        std::string cRLQ = "\033[100m\033[38;5;0m##";
    }

    std::string border = "\033[48;5;1m  ";
    std::string grassblock = "\033[48;5;2m  ";
    std::string rock = "\033[100m  ";
    std::string soil = "\033[48;5;52m  ";
    std::string wood = "\033[48;5;130m  ";
    std::string leaves = "\033[48;5;34m  ";

    std::string copper = "\033[100m\033[38;5;166m::";
    std::string iron = "\033[100m\033[37m::";
    std::string gold = "\033[100m\033[38;5;220m::";
    std::string diamond = "\033[100m\033[38;5;45m::";
}