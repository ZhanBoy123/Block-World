#pragma once

enum class things {

	// 基础方块
	air,
	border,
	grassblock,
	soil,
	rock,
	leaves,
	wood,

	// 矿物(原矿石)
	copper, // 铜
	iron,   // 铁
	gold,   // 黄金
	diamond,// 钻石
	// (转化后)
	copper2,
	iron2,
	gold2,
	diamond2,

	// 动物
	pig,
	sheep,

	// 植物（游戏特定植物）
	LM,// 梁米

	// other
	RLQ,// 熔炼器
};